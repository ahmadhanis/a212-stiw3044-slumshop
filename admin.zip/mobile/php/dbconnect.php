<?php
$servername = "localhost";
$username   = "slumber6_slumshop_admin";
$password   = "wMNfNU9p*NEi";
$dbname     = "slumber6_slumshop_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
