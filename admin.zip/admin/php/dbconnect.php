<?php
$servername = "localhost";
$username   = "slumber6_slumshop_admin";
$password   = "wMNfNU9p*NEi";
$dbname     = "slumber6_slumshop_db";

try {
  $conn = new PDO("mysql:host=$servername;dbname=slumber6_slumshop_db", $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}
?>
